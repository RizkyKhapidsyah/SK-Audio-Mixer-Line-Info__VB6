version 2.0 uploaded 04/02/99
Techniques demonstrated in this project
---------------------------------------
-Using the Win32 audio mixer functions from VB
-Obtaining detailed audio device capabilities
-"walking" the lines of multiple soundcards
-wrapping much of the mixer object functionality in a VB class

This version contains additions by Dave Snyder,
who has freely offered to share his work to help 
VBers understand the Win32 Mixer API.  Thanks Dave!

You may freely use and modify this code in your 
own programs.  However, you may not redistribute 
this sample without permission from Ray Mercer 
<raymer@macnica.co.jp>

Copyright (C) 1998-1999 by Shrinkwrap Visual Basic,
all rights reserved